package com.example.eulerity;

public enum Filter{
    NONE,
    GRAYSCALE,
    SEPIA,
    INVERT
}